        <?php $base_url2 = "http://localhost:8888/paymentsystem/user-login/maker"; ?>
        <!-- Sidenav Menu -->
        <aside id="sidebar">
            <strong class="logo"><a href="#">lg</a></strong>
            <ul class="tabset buttons">
                <li class="sidenav_menu">
                    <a href="<?= $base_url2; ?>/index_new.php?branch=Pampanga">SBC</a>
                </li>

                <li class="sidenav_menu  active">
                    <a href="<?= $base_url2; ?>/bdo/bdo_index.php?branch=Pampanga" >BDO</a>
                </li>

                <li>
                    <a href="settings.php" class="ico8"><span>Settings</span><em></em></a>
                    <span class="tooltip"><span>Settings</span></span>
                </li>
            </ul>
            <span class="shadow"></span>
        </aside>
        <!-- End Sidenav Menu -->

    </div>
</body>